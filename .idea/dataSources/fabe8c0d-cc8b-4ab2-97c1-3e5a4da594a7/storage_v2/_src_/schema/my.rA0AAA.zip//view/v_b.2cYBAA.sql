create definer = root@localhost view v_b as
select `my`.`books`.`id`       AS `id`,
       `my`.`books`.`bookName` AS `bookName`,
       `my`.`books`.`counts`   AS `counts`,
       `my`.`books`.`detail`   AS `detail`
from `my`.`books`;

